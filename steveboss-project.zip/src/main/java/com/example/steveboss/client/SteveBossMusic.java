package com.example.steveboss.client;

import com.example.steveboss.SteveSounds;
import com.example.steveboss.entity.SteveBossEntity;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Client-only looping boss theme.
 *  - Non-positional (plays at the same volume everywhere), routed through the MUSIC slider.
 *  - Fades out when the boss dies/despawns or the player walks > 64 blocks away.
 *  - Phase hook: pitch/volume nudge per phase (or swap to a different track, see IMPLEMENTATION_GUIDE.md).
 * Only ever referenced from SteveBossEntity#onAddedToWorld via DistExecutor, so it never loads on a dedicated server.
 */
@OnlyIn(Dist.CLIENT)
public class SteveBossMusic extends AbstractTickableSoundInstance {

    private static SteveBossMusic current;

    private final SteveBossEntity boss;
    private float fade = 1.0f;

    /** Entry point called from the entity. Ignores duplicate starts. */
    public static void start(SteveBossEntity boss) {
        Minecraft mc = Minecraft.getInstance();
        if (current != null && !current.isStopped()) return;
        mc.getMusicManager().stopPlaying();          // silence vanilla background music
        current = new SteveBossMusic(boss);
        mc.getSoundManager().play(current);
    }

    private SteveBossMusic(SteveBossEntity boss) {
        super(SteveSounds.BOSS_MUSIC.get(), SoundSource.MUSIC, SoundInstance.createUnseededRandom());
        this.boss = boss;
        this.looping = true;
        this.delay = 0;
        this.volume = 1.0f;
        this.relative = true;                         // follows the listener, no 3D falloff
        this.attenuation = SoundInstance.Attenuation.NONE;
    }

    @Override
    public void tick() {
        Player player = Minecraft.getInstance().player;
        boolean boss_gone = boss.isRemoved() || !boss.isAlive();
        boolean too_far = player == null || player.distanceToSqr(boss) > 64.0 * 64.0;

        // Fade out over ~2 s when the fight is over / left; fade back in if the player returns
        fade = (boss_gone || too_far) ? fade - 0.025f : Math.min(1.0f, fade + 0.05f);
        if (fade <= 0.0f) {
            if (boss_gone) { stop(); current = null; } else { fade = 0.0f; }
            return;
        }

        // Phase-based intensity (single-track version). Subtle: +0 / +3% / +6% pitch.
        float phasePitch = 1.0f + boss.getPhase().ordinal() * 0.03f;
        this.pitch = phasePitch;
        this.volume = fade;
    }
}
