package com.example.steveboss.client;

import com.example.steveboss.SteveBossMod;
import com.example.steveboss.entity.SteveBossEntity;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

/** Renders Steve with the player model, your skin, and the diamond armor he wears. */
public class SteveBossRenderer extends HumanoidMobRenderer<SteveBossEntity, PlayerModel<SteveBossEntity>> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(SteveBossMod.MODID, "textures/entity/steve_boss.png");

    public SteveBossRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PlayerModel<>(ctx.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                ctx.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(SteveBossEntity entity) {
        return TEXTURE;
    }
}
