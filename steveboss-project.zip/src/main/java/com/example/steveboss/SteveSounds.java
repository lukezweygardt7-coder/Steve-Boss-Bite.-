package com.example.steveboss;

import java.util.function.Supplier;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Sound hooks. Everything the boss plays goes through here, so swapping audio never touches AI code.
 *
 * - BOSS_MUSIC is a real custom event (drop your .ogg in, see IMPLEMENTATION_GUIDE.md section 5).
 * - The rest are PLACEHOLDERS pointing at vanilla sounds. To use custom audio later, replace the right-hand side with
 *   `register("steve_teleport")` etc. (RegistryObject is a Supplier<SoundEvent>, so nothing else changes)
 *   and add the matching entry to sounds.json.
 */
public final class SteveSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, SteveBossMod.MODID);

    public static final RegistryObject<SoundEvent> BOSS_MUSIC = register("boss_music");

    // ---- placeholders (vanilla) ----
    public static final Supplier<SoundEvent> TELEPORT   = () -> SoundEvents.ENDERMAN_TELEPORT;
    public static final Supplier<SoundEvent> PHASE_ROAR = () -> SoundEvents.ENDER_DRAGON_GROWL;
    public static final Supplier<SoundEvent> SLAM       = () -> SoundEvents.ANVIL_LAND;
    public static final Supplier<SoundEvent> PARRY      = () -> SoundEvents.SHIELD_BLOCK;

    private static RegistryObject<SoundEvent> register(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(SteveBossMod.MODID, name)));
    }

    /** Call from your mod constructor: SteveSounds.register(modEventBus); */
    public static void register(IEventBus bus) { SOUNDS.register(bus); }

    private SteveSounds() {}
}
