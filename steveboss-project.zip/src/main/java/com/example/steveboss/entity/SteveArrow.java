package com.example.steveboss.entity;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.SpectralArrow;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Armor-piercing spectral arrow for the Phase 3 barrage.
 *
 * Trick: we extend SpectralArrow and use its (Level, LivingEntity) constructor, so the entity TYPE is still
 * vanilla spectral_arrow. That means: no EntityType registration, no client renderer, and the client just
 * sees a normal glowing arrow. All the custom behaviour is server-side.
 *
 * Armor bypass: indirectMagic damage is in the vanilla bypasses_armor tag. Resistance and Protection
 * enchantments still apply. Whether a raised player shield blocks it depends on vanilla's bypasses_shield tag - test in game.
 */
public class SteveArrow extends SpectralArrow {

    /** 3.0 = 1.5 hearts per arrow, ~6 damage/second because of the 10-tick hurt window. Tune to taste. */
    private static final float DAMAGE = 3.0f;
    private static final int MAX_LIFETIME_TICKS = 80;

    public SteveArrow(Level level, LivingEntity owner) {
        super(level, owner);
        this.setNoGravity(true);   // laser-straight barrage
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount > MAX_LIFETIME_TICKS) discard();
    }

    @Override
    protected void onHitEntity(EntityHitResult hit) {
        Entity target = hit.getEntity();
        Entity owner = getOwner();

        // Pass straight through the boss and his minions
        if (target == owner || target instanceof SteveBossEntity || target.getTags().contains(SteveBossEntity.TAG_MINION)) {
            return;
        }
        if (!level().isClientSide && target instanceof LivingEntity living) {
            DamageSource src = level().damageSources().indirectMagic(this, owner != null ? owner : this);
            if (living.hurt(src, DAMAGE)) {
                living.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0), owner);
            }
            playSound(SoundEvents.ARROW_HIT, 1.0f, 1.2f);
        }
        discard();
    }
}
