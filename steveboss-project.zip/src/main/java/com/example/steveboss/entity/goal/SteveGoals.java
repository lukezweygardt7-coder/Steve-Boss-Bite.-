package com.example.steveboss.entity.goal;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

import com.example.steveboss.SteveSounds;
import com.example.steveboss.entity.SteveArrow;
import com.example.steveboss.entity.SteveBossEntity;
import com.example.steveboss.entity.SteveBossEntity.Ability;
import com.example.steveboss.entity.SteveBossEntity.Phase;
import com.example.steveboss.entity.SteveBossEntity.State;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/**
 * Every custom AI goal for Steve, as static nested classes so the whole kit lives in one file.
 *
 * Goal-flag cheat sheet used below:
 *   MOVE+LOOK  -> "takes over the body" (teleport, slam, shield, rush/barrage, melee)
 *   (none)     -> runs alongside whatever else is active (TNT)
 */
public final class SteveGoals {

    private SteveGoals() {}

    // =====================================================================================
    // Phase lock: freezes Steve during phase roars and the totem pop animation.
    // =====================================================================================
    public static class PhaseLockGoal extends Goal {
        private final SteveBossEntity boss;

        public PhaseLockGoal(SteveBossEntity boss) {
            this.boss = boss;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override public boolean canUse() { return boss.isLocked(); }
        @Override public boolean canContinueToUse() { return boss.isLocked(); }
        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void start() { boss.getNavigation().stop(); boss.setSprinting(false); }
    }

    // =====================================================================================
    // 1. TELEPORT BEHIND  (Phase 1+)
    //    Trigger A: target out of melee range for >= 3 s     (entity tracks ticksOutOfMelee)
    //    Trigger B: Steve was hit by a projectile in the last second
    // =====================================================================================
    public static class TeleportBehindGoal extends Goal {
        public static final int OUT_OF_RANGE_TICKS = 60; // 3 seconds
        private static final int COOLDOWN_TICKS = 100;

        private final SteveBossEntity boss;

        public TeleportBehindGoal(SteveBossEntity boss) {
            this.boss = boss;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity target = boss.getTarget();
            if (target == null || !target.isAlive() || boss.isLocked() || boss.isShielding()) return false;
            if (!boss.isReady(Ability.TELEPORT)) return false;
            if (boss.distanceToSqr(target) > 40.0 * 40.0) return false;
            return boss.getTicksOutOfMelee() >= OUT_OF_RANGE_TICKS || boss.wasRecentlyShot();
        }

        /** Instant ability: do everything in start(); canContinueToUse() is false so the goal ends immediately. */
        @Override
        public void start() {
            LivingEntity target = boss.getTarget();
            if (target == null || !(boss.level() instanceof ServerLevel level)) return;

            Vec3 dest = findBehindPosition(level, target);
            boss.resetOutOfMelee();
            boss.clearShotReaction();
            if (dest == null) {               // no safe spot (tight cave, etc.) -> retry soon
                boss.startCooldown(Ability.TELEPORT, 20);
                return;
            }

            teleportFx(level, boss.position(), false);   // departure puff
            boss.teleportTo(dest.x, dest.y, dest.z);
            boss.getNavigation().stop();
            boss.lookAt(net.minecraft.commands.arguments.EntityAnchorArgument.Anchor.EYES, target.getEyePosition());
            teleportFx(level, dest, true);               // arrival burst

            boss.setAbilityState(State.TELEPORT, 8);
            boss.resetMeleeCooldown();                   // guarantees an immediate backstab opportunity
            boss.startCooldown(Ability.TELEPORT, COOLDOWN_TICKS);
        }

        @Override public boolean canContinueToUse() { return false; }

        /** Looks for a free, grounded spot 1.5-3 blocks behind the target's facing direction. */
        private Vec3 findBehindPosition(ServerLevel level, LivingEntity target) {
            Vec3 look = target.getLookAngle();
            Vec3 flat = new Vec3(look.x, 0, look.z);
            if (flat.lengthSqr() < 1.0E-4) flat = Vec3.directionFromRotation(0, target.getYRot());
            Vec3 behind = flat.normalize().reverse();

            double[] distances = {2.0, 2.5, 3.0, 1.5};
            double[] angles = {0, 35, -35, 70, -70};
            for (double dist : distances) {
                for (double angle : angles) {
                    Vec3 dir = behind.yRot((float) Math.toRadians(angle));
                    double x = target.getX() + dir.x * dist;
                    double z = target.getZ() + dir.z * dist;
                    for (int dy : new int[]{0, -1, 1}) {
                        double y = target.getY() + dy;
                        BlockPos feet = BlockPos.containing(x, y, z);
                        BlockPos floor = feet.below();
                        if (!level.getBlockState(floor).isFaceSturdy(level, floor, Direction.UP)) continue;
                        AABB box = boss.getBoundingBox().move(x - boss.getX(), feet.getY() - boss.getY(), z - boss.getZ());
                        if (level.noCollision(boss, box) && !level.containsAnyLiquid(box)) {
                            return new Vec3(x, feet.getY(), z);
                        }
                    }
                }
            }
            return null;
        }

        /** Purple vortex: portal swirl + witch sparks + a rising dust spiral. Hook your own sound in SteveSounds.TELEPORT. */
        private void teleportFx(ServerLevel level, Vec3 pos, boolean arriving) {
            level.playSound(null, pos.x, pos.y, pos.z, SteveSounds.TELEPORT.get(), SoundSource.HOSTILE, 1.4f, arriving ? 1.0f : 0.8f);
            level.sendParticles(arriving ? ParticleTypes.REVERSE_PORTAL : ParticleTypes.PORTAL,
                    pos.x, pos.y + 1.0, pos.z, 60, 0.4, 0.9, 0.4, arriving ? 0.15 : 0.8);
            level.sendParticles(ParticleTypes.WITCH, pos.x, pos.y + 1.0, pos.z, 20, 0.4, 0.8, 0.4, 0.05);
            DustParticleOptions purple = new DustParticleOptions(new Vector3f(0.62f, 0.15f, 0.95f), 1.5f);
            int points = 24;
            for (int i = 0; i < points; i++) {
                double a = i * (Math.PI * 2 / points);
                level.sendParticles(purple, pos.x + Math.cos(a) * 0.8, pos.y + i * 0.08, pos.z + Math.sin(a) * 0.8, 1, 0, 0, 0, 0);
            }
        }
    }

    // =====================================================================================
    // 2. TNT SURPRISE  (all phases; more TNT as phases rise)
    //    Mode A "feet":   primed TNT spawns on the player's position (fuse 1.75 s = dodgeable).
    //    Mode B "orbit":  a ring of TNT circles Steve for 1.5 s, then is flung outward.
    //    Blocks are protected / boss + minions are immune via SteveBossEvents (TAG_TNT).
    // =====================================================================================
    public static class TntSurpriseGoal extends Goal {
        private static final int ORBIT_TICKS = 30;
        private static final int ORBIT_COUNT = 6;
        private static final double ORBIT_RADIUS = 2.6;
        private static final int MAX_LIVE_TNT = 12;

        private final SteveBossEntity boss;
        private final List<PrimedTnt> orbiting = new ArrayList<>();
        private int ticks;
        private double angle;

        public TntSurpriseGoal(SteveBossEntity boss) {
            this.boss = boss;
            setFlags(EnumSet.noneOf(Flag.class)); // no flags -> can run while moving/meleeing
        }

        @Override
        public boolean canUse() {
            LivingEntity target = boss.getTarget();
            return target != null && target.isAlive() && !boss.isLocked() && !boss.isShielding()
                    && boss.isReady(Ability.TNT) && boss.distanceToSqr(target) < 20.0 * 20.0;
        }

        @Override
        public void start() {
            LivingEntity target = boss.getTarget();
            if (target == null || !(boss.level() instanceof ServerLevel level)) return;

            // Safety valve: never let the arena fill with TNT.
            AABB arena = boss.getBoundingBox().inflate(40.0);
            if (level.getEntitiesOfClass(PrimedTnt.class, arena, t -> t.getTags().contains(SteveBossEntity.TAG_TNT)).size() > MAX_LIVE_TNT) {
                boss.startCooldown(Ability.TNT, 40);
                return;
            }

            ticks = 0;
            orbiting.clear();
            boolean orbit = boss.getRandom().nextFloat() < 0.4f;

            if (orbit) {
                for (int i = 0; i < ORBIT_COUNT; i++) {
                    PrimedTnt tnt = spawnTnt(level, boss.getX(), boss.getY() + 1.0, boss.getZ(), ORBIT_TICKS + 25);
                    tnt.setNoGravity(true);
                    orbiting.add(tnt);
                }
                boss.startCooldown(Ability.TNT, 160);
            } else {
                // 1 TNT directly under the player, +1 extra per phase scattered within 2.5 blocks
                spawnTnt(level, target.getX(), target.getY(), target.getZ(), 35);
                for (int i = 0; i < boss.getPhase().ordinal(); i++) {
                    double a = boss.getRandom().nextDouble() * Math.PI * 2;
                    double r = 1.5 + boss.getRandom().nextDouble();
                    spawnTnt(level, target.getX() + Math.cos(a) * r, target.getY(), target.getZ() + Math.sin(a) * r, 45 + i * 10);
                }
                boss.startCooldown(Ability.TNT, 100);
            }
        }

        private PrimedTnt spawnTnt(ServerLevel level, double x, double y, double z, int fuse) {
            PrimedTnt tnt = new PrimedTnt(level, x, y, z, boss);
            tnt.setFuse(fuse);
            tnt.setDeltaMovement(Vec3.ZERO);   // constructor adds a small random hop; we want it to stay put
            tnt.addTag(SteveBossEntity.TAG_TNT);
            level.addFreshEntity(tnt);
            level.playSound(null, x, y, z, SoundEvents.TNT_PRIMED, SoundSource.HOSTILE, 1.0f, 1.0f);
            return tnt;
        }

        @Override public boolean canContinueToUse() { return !orbiting.isEmpty() && ticks < ORBIT_TICKS; }
        @Override public boolean requiresUpdateEveryTick() { return true; }

        /** Orbit: re-pose the TNT on a spinning ring every tick (vanilla TNT has no orbit behaviour). */
        @Override
        public void tick() {
            ticks++;
            angle += 0.35;
            for (int i = 0; i < orbiting.size(); i++) {
                PrimedTnt tnt = orbiting.get(i);
                if (!tnt.isAlive()) continue;
                double a = angle + i * (Math.PI * 2 / orbiting.size());
                tnt.setPos(boss.getX() + Math.cos(a) * ORBIT_RADIUS,
                        boss.getY() + 1.0 + Math.sin(ticks * 0.2 + i) * 0.25,
                        boss.getZ() + Math.sin(a) * ORBIT_RADIUS);
                tnt.setDeltaMovement(Vec3.ZERO);
                tnt.hasImpulse = true;
            }
        }

        /** Release: fling the ring outward so the player must run / jump through the blast zone. */
        @Override
        public void stop() {
            for (PrimedTnt tnt : orbiting) {
                if (!tnt.isAlive()) continue;
                Vec3 out = new Vec3(tnt.getX() - boss.getX(), 0, tnt.getZ() - boss.getZ());
                out = out.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : out.normalize();
                tnt.setNoGravity(false);
                tnt.setDeltaMovement(out.x * 0.7, 0.25, out.z * 0.7);
            }
            orbiting.clear();
        }
    }

    // =====================================================================================
    // 3. ZOMBIE HORDE SLAM  (Phase 2+)
    //    Windup -> impact tick (sync with your slam animation hit-frame) -> shockwave + 3-4 iron-geared zombies.
    // =====================================================================================
    public static class SummonHordeGoal extends Goal {
        /** Tick of the SLAM animation at which the fists hit the ground. Match this to your keyframe (18t = 0.9 s). */
        public static final int IMPACT_TICK = 18;
        public static final int TOTAL_TICKS = 32;
        private static final int MAX_MINIONS = 8;
        private static final int COOLDOWN_TICKS = 400; // 20 s

        private final SteveBossEntity boss;
        private int ticks;

        public SummonHordeGoal(SteveBossEntity boss) {
            this.boss = boss;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            LivingEntity target = boss.getTarget();
            return boss.getPhase().ordinal() >= Phase.TWO.ordinal()
                    && target != null && target.isAlive()
                    && !boss.isLocked() && !boss.isShielding()
                    && boss.isReady(Ability.HORDE)
                    && boss.distanceToSqr(target) < 16.0 * 16.0
                    && boss.countMinions() + 3 <= MAX_MINIONS;
        }

        @Override
        public void start() {
            ticks = 0;
            boss.getNavigation().stop();
            boss.setSprinting(false);
            boss.setAbilityState(State.SLAM, TOTAL_TICKS);
            boss.playSound(SoundEvents.RAVAGER_ROAR, 1.5f, 0.7f); // windup growl; swap for a custom cue
        }

        @Override public boolean canContinueToUse() { return ticks < TOTAL_TICKS; }
        @Override public boolean requiresUpdateEveryTick() { return true; }

        @Override
        public void tick() {
            LivingEntity target = boss.getTarget();
            if (target != null) boss.getLookControl().setLookAt(target, 60f, 60f);
            if (++ticks == IMPACT_TICK && boss.level() instanceof ServerLevel level) {
                boss.shockwave(9.0, 1.8f, 6.0f);
                summonWave(level, target);
            }
        }

        @Override public void stop() { boss.startCooldown(Ability.HORDE, COOLDOWN_TICKS); }

        /** Spawns 3-4 iron-armored zombies in a ring 3-6 blocks around Steve. */
        private void summonWave(ServerLevel level, LivingEntity target) {
            int count = 3 + boss.getRandom().nextInt(2);
            for (int i = 0; i < count; i++) {
                Zombie z = EntityType.ZOMBIE.create(level);
                if (z == null) continue;
                Vec3 spot = findGroundSpot(level, z);
                if (spot == null) continue;

                z.moveTo(spot.x, spot.y, spot.z, boss.getRandom().nextFloat() * 360f, 0f);
                z.addTag(SteveBossEntity.TAG_MINION);
                z.setCanPickUpLoot(false);
                z.setBaby(false);
                z.setPersistenceRequired();

                // Iron kit, zero drops (no loot farming from the horde)
                z.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.IRON_HELMET));   // also stops daylight burning
                z.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.IRON_CHESTPLATE));
                z.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.IRON_LEGGINGS));
                z.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.IRON_BOOTS));
                z.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_SWORD));
                for (EquipmentSlot slot : EquipmentSlot.values()) z.setDropChance(slot, 0.0f);

                // A bit tougher / quicker than vanilla so they actually distract
                z.getAttribute(Attributes.MAX_HEALTH).setBaseValue(30.0);
                z.setHealth(30.0f);
                z.getAttribute(Attributes.MOVEMENT_SPEED).setBaseValue(0.27);

                if (target != null) z.setTarget(target);
                level.addFreshEntity(z);
                boss.registerMinion(z);

                level.sendParticles(ParticleTypes.SOUL, spot.x, spot.y + 0.5, spot.z, 15, 0.3, 0.5, 0.3, 0.05);
                level.sendParticles(ParticleTypes.LARGE_SMOKE, spot.x, spot.y + 0.2, spot.z, 8, 0.3, 0.1, 0.3, 0.02);
            }
        }

        /** Random ring position with solid floor and room for a zombie. */
        private Vec3 findGroundSpot(ServerLevel level, Zombie z) {
            for (int attempt = 0; attempt < 16; attempt++) {
                double ang = boss.getRandom().nextDouble() * Math.PI * 2;
                double r = 3.0 + boss.getRandom().nextDouble() * 3.0;
                double x = boss.getX() + Math.cos(ang) * r;
                double zz = boss.getZ() + Math.sin(ang) * r;
                for (int dy = 2; dy >= -3; dy--) {
                    BlockPos feet = BlockPos.containing(x, boss.getY() + dy, zz);
                    BlockPos below = feet.below();
                    if (level.getBlockState(below).isFaceSturdy(level, below, Direction.UP)) {
                        z.setPos(x, feet.getY(), zz);
                        if (level.noCollision(z)) return new Vec3(x, feet.getY(), zz);
                        break;
                    }
                }
            }
            return null;
        }
    }

    // =====================================================================================
    // 4. SHIELD BLOCK & PARRY  (Phase 2+)
    //    Raises a shield for 2 s. The parry itself (negate + sweeping counter + Slowness/Weakness)
    //    lives in SteveBossEntity#hurt / parryCounter so it can intercept damage.
    // =====================================================================================
    public static class ShieldParryGoal extends Goal {
        private static final int COOLDOWN_TICKS = 200;

        private final SteveBossEntity boss;

        public ShieldParryGoal(SteveBossEntity boss) {
            this.boss = boss;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity target = boss.getTarget();
            if (boss.getPhase().ordinal() < Phase.TWO.ordinal() || target == null || !target.isAlive()) return false;
            if (boss.isLocked() || !boss.isReady(Ability.SHIELD)) return false;
            double d = boss.distanceToSqr(target);
            // "Occasionally": only when the player is close, and only ~1 in 30 polls
            return d > 2.0 * 2.0 && d < 6.0 * 6.0 && boss.getRandom().nextInt(30) == 0;
        }

        @Override public void start() { boss.getNavigation().stop(); boss.setSprinting(false); boss.beginShield(); }
        @Override public boolean canContinueToUse() { return boss.isShielding(); }
        @Override public boolean requiresUpdateEveryTick() { return true; }

        @Override
        public void tick() {
            LivingEntity target = boss.getTarget();
            if (target == null) return;
            boss.getLookControl().setLookAt(target, 60f, 60f);
            // Slow, menacing advance while blocking
            if (boss.distanceToSqr(target) > 3.0 * 3.0) boss.getNavigation().moveTo(target, 0.6);
        }

        @Override
        public void stop() {
            boss.endShield();   // no-op if the parry already ended it
            boss.startCooldown(Ability.SHIELD, COOLDOWN_TICKS);
        }
    }

    // =====================================================================================
    // 5. PHASE 3: GIGA-SPRINT <-> BOW BARRAGE
    //    Alternates ~5-7 s sword rushes with ~3 s of rapid-fire armor-piercing spectral arrows.
    // =====================================================================================
    public static class RushAndBarrageGoal extends Goal {
        private enum Mode { RUSH, BARRAGE }

        private final SteveBossEntity boss;
        private Mode mode = Mode.RUSH;
        private int modeTicks, shotTimer, strafeTicks, repathTicks;
        private float strafeDir = 1f;

        public RushAndBarrageGoal(SteveBossEntity boss) {
            this.boss = boss;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = boss.getTarget();
            return boss.getPhase() == Phase.THREE && t != null && t.isAlive() && !boss.isLocked();
        }

        @Override public boolean canContinueToUse() { return canUse(); }
        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void start() { enter(Mode.RUSH); }

        private void enter(Mode next) {
            mode = next;
            if (next == Mode.RUSH) {
                modeTicks = 100 + boss.getRandom().nextInt(40);
                boss.equipSword();
                boss.setGigaSprint(true);
                boss.setAbilityState(State.GIGA_SPRINT, modeTicks);
            } else {
                modeTicks = 50 + boss.getRandom().nextInt(20);
                boss.setGigaSprint(false);
                boss.setSprinting(false);
                boss.equipBow();
                boss.setAbilityState(State.BOW_DRAW, modeTicks);
                shotTimer = 12; // draw delay before the first volley
            }
        }

        @Override
        public void tick() {
            LivingEntity t = boss.getTarget();
            if (t == null) return;
            boss.getLookControl().setLookAt(t, 60f, 60f);

            if (--modeTicks <= 0) { enter(mode == Mode.RUSH ? Mode.BARRAGE : Mode.RUSH); return; }

            double distSqr = boss.distanceToSqr(t);
            if (mode == Mode.RUSH) {
                boss.setSprinting(true);
                if (--repathTicks <= 0) {
                    repathTicks = 4;
                    boss.getNavigation().moveTo(t, 1.3);
                }
                boolean falling = !boss.onGround() && boss.getDeltaMovement().y < 0;
                if (distSqr <= 3.2 * 3.2) boss.tryMeleeHit(t, falling);
                if (boss.onGround() && distSqr < 6.0 * 6.0 && boss.getRandom().nextInt(25) == 0) boss.getJumpControl().jump();
            } else {
                // Kite: hold 8-16 blocks away and strafe like a bow-spamming PvP player
                if (--strafeTicks <= 0) {
                    strafeTicks = 10 + boss.getRandom().nextInt(15);
                    strafeDir = boss.getRandom().nextBoolean() ? 1f : -1f;
                }
                double dist = Math.sqrt(distSqr);
                float forward = dist < 8 ? -0.7f : dist > 16 ? 0.7f : 0f;
                boss.getNavigation().stop();
                boss.getMoveControl().strafe(forward, strafeDir * 0.7f);

                if (boss.hasLineOfSight(t) && --shotTimer <= 0) {
                    shotTimer = 4; // 5 arrows / second
                    fireArrow(t);
                }
            }
        }

        private void fireArrow(LivingEntity target) {
            SteveArrow arrow = new SteveArrow(boss.level(), boss);
            arrow.setPos(boss.getX(), boss.getEyeY() - 0.1, boss.getZ());
            double dx = target.getX() - boss.getX();
            double dy = target.getY(0.33) - arrow.getY();
            double dz = target.getZ() - boss.getZ();
            double horiz = Math.sqrt(dx * dx + dz * dz);
            arrow.shoot(dx, dy + horiz * 0.04, dz, 2.8f, 2.0f); // velocity, inaccuracy
            arrow.pickup = AbstractArrow.Pickup.DISALLOWED;
            boss.level().addFreshEntity(arrow);
            boss.playSound(SoundEvents.ARROW_SHOOT, 1.0f, 1.3f + boss.getRandom().nextFloat() * 0.3f);
        }

        @Override
        public void stop() {
            boss.setGigaSprint(false);
            boss.setSprinting(false);
            boss.equipSword();
            boss.getNavigation().stop();
        }
    }

    // =====================================================================================
    // 6. CRITICAL MELEE + ERRATIC PVP MOVEMENT  (Phase 1-2 default behaviour)
    //    - Chase with jittered path targets so the route is never a clean line
    //    - Close range: circle-strafe, random hops, and land crits while falling
    //    - Occasional long leap-in for a big critical
    // =====================================================================================
    public static class CriticalMeleeGoal extends Goal {
        private static final double REACH_SQR = 3.0 * 3.0;

        private final SteveBossEntity boss;
        private int repathTicks, strafeTicks, leapCooldown, leapTicks;
        private float strafeDir = 1f;
        private boolean leaping;

        public CriticalMeleeGoal(SteveBossEntity boss) {
            this.boss = boss;
            setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK, Flag.JUMP));
        }

        @Override public boolean canUse() { LivingEntity t = boss.getTarget(); return t != null && t.isAlive(); }
        @Override public boolean canContinueToUse() { return canUse(); }
        @Override public boolean requiresUpdateEveryTick() { return true; }

        @Override
        public void stop() {
            boss.getNavigation().stop();
            boss.setSprinting(false);
            leaping = false;
        }

        @Override
        public void tick() {
            LivingEntity t = boss.getTarget();
            if (t == null) return;
            boss.getLookControl().setLookAt(t, 40f, 40f);

            double distSqr = boss.distanceToSqr(t);
            double dist = Math.sqrt(distSqr);
            if (leapCooldown > 0) leapCooldown--;
            boss.setSprinting(dist > 3.0);

            // --- Leap-in: jump from mid range, crit on the way down ---
            if (!leaping && leapCooldown == 0 && boss.onGround() && dist > 3.5 && dist < 7.0
                    && boss.getRandom().nextInt(12) == 0) {
                boss.leapAt(t);
                leaping = true;
                leapTicks = 0;
                leapCooldown = 50 + boss.getRandom().nextInt(30);
                return;
            }
            if (leaping) {
                leapTicks++;
                if (boss.getDeltaMovement().y < 0 && distSqr <= 3.4 * 3.4) boss.tryMeleeHit(t, true);
                if ((leapTicks > 4 && boss.onGround()) || leapTicks > 40) leaping = false;
                return;
            }

            boolean falling = !boss.onGround() && boss.getDeltaMovement().y < -0.05;

            // --- Close quarters: strafe, hop, hit ---
            if (distSqr <= REACH_SQR + 1.0) {
                boss.tryMeleeHit(t, falling);       // falling => crit (like a real jump-crit)
                if (--strafeTicks <= 0) {
                    strafeTicks = 8 + boss.getRandom().nextInt(20);
                    strafeDir = boss.getRandom().nextBoolean() ? 1f : -1f;
                }
                if (boss.onGround() && boss.getRandom().nextInt(30) == 0) boss.getJumpControl().jump();
                boss.getNavigation().stop();
                boss.getMoveControl().strafe(dist < 2.0 ? -0.3f : 0.3f, strafeDir * 0.8f);
            }
            // --- Chase with a jittered destination so the path wobbles like a human's ---
            else if (--repathTicks <= 0) {
                repathTicks = 3 + boss.getRandom().nextInt(5);
                double ox = (boss.getRandom().nextDouble() - 0.5) * 2.0;
                double oz = (boss.getRandom().nextDouble() - 0.5) * 2.0;
                boss.getNavigation().moveTo(t.getX() + ox, t.getY(), t.getZ() + oz, 1.15);
            }
        }
    }
}
