package com.example.steveboss.entity;

import java.util.EnumMap;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import com.example.steveboss.SteveSounds;
import com.example.steveboss.client.SteveBossMusic;
import com.example.steveboss.entity.goal.SteveGoals;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;

/**
 * "Steve" - the ultimate PvP boss.  Forge 1.20.1, official (Mojang) mappings.
 *
 * Design rules:
 *  - The entity owns ALL state (phase, cooldowns, shield timer, minions). Goals only read/write it
 *    through the small public API at the bottom, so goals stay short and easy to tune.
 *  - Phase + ability state are synced to the client via SynchedEntityData, so a renderer / GeckoLib
 *    controller can pick animations without any custom packets.
 *  - Cooldowns are ticked in customServerAiStep (every tick), NOT inside Goal#canUse (which the
 *    GoalSelector only polls every few ticks).
 */
public class SteveBossEntity extends Monster {

    // ------------------------------------------------------------------ constants

    public static final String TAG_MINION = "steve_minion";
    public static final String TAG_TNT = "steve_tnt";

    public enum Phase { ONE, TWO, THREE }

    /** Drives animations on the client. Add values freely - it is just an int on the wire. */
    public enum State {
        NONE, CRIT_LEAP, TELEPORT, SLAM, SHIELD, PARRY_STRIKE, TOTEM, BOW_DRAW, GIGA_SPRINT, PHASE_ROAR
    }

    public enum Ability { TELEPORT, TNT, HORDE, SHIELD }

    private static final float PHASE_TWO_RATIO = 0.60f;
    private static final float PHASE_THREE_RATIO = 0.20f;
    private static final float TOTEM_HEAL = 100.0f;
    /** Anything bigger than this is clamped (stops creative-tier burst damage trivialising the fight). */
    private static final float DAMAGE_CAP = 40.0f;
    private static final float CRIT_MULTIPLIER = 2.0f;
    public static final int SHIELD_DURATION = 40; // 2 seconds
    private static final UUID GIGA_SPRINT_UUID = UUID.fromString("5b0f7c3e-2d9a-4c1e-9a53-8d6e1f0a7b11");

    private static final EntityDataAccessor<Integer> DATA_PHASE =
            SynchedEntityData.defineId(SteveBossEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_STATE =
            SynchedEntityData.defineId(SteveBossEntity.class, EntityDataSerializers.INT);

    // ------------------------------------------------------------------ state

    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.literal("Steve"), BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.NOTCHED_20);

    private final EnumMap<Ability, Integer> cooldowns = new EnumMap<>(Ability.class);
    private final Set<UUID> minionIds = new HashSet<>();

    private boolean totemUsed;
    private int lockTicks;          // >0 : roaring / totem animation, boss is invulnerable and frozen
    private int stateTicks;         // how long the current animation State stays set
    private int meleeCooldown;
    private int shieldTicks;        // >0 : shield raised, parry window open
    private int ticksOutOfMelee;    // consecutive ticks the target has been out of melee range
    private int shotReactionTicks;  // >0 : recently hit by a projectile -> teleport trigger

    // ------------------------------------------------------------------ setup

    public SteveBossEntity(EntityType<? extends SteveBossEntity> type, Level level) {
        super(type, level);
        this.xpReward = 500;
        this.setPersistenceRequired();
        equipSword();
        setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.DIAMOND_HELMET));
        setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.DIAMOND_CHESTPLATE));
        setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.DIAMOND_LEGGINGS));
        setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.DIAMOND_BOOTS));
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            setDropChance(slot, 0.0f);
        }
    }

    /**
     * Armor maths (vanilla): with armor 12 / toughness 6 a 7-damage diamond-sword hit is reduced by ~40%.
     * That is ~4.2 per hit => about 120 hits for 500 HP + 100 totem HP. Raise ARMOR for a longer fight.
     */
    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 500.0)
                .add(Attributes.ARMOR, 12.0)
                .add(Attributes.ARMOR_TOUGHNESS, 6.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0)
                // Player sprint is ~0.13 in attribute terms but mobs move through different friction paths;
                // 0.36 feels "slightly faster than a sprinting player" - tune in-game.
                .add(Attributes.MOVEMENT_SPEED, 0.36)
                .add(Attributes.ATTACK_DAMAGE, 9.0)
                .add(Attributes.ATTACK_KNOCKBACK, 0.5)
                .add(Attributes.FOLLOW_RANGE, 48.0);
    }

    @Override
    protected void registerGoals() {
        // priority 0: always-on
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(0, new SteveGoals.PhaseLockGoal(this));
        // priority 1: reactive repositioning beats everything else
        this.goalSelector.addGoal(1, new SteveGoals.TeleportBehindGoal(this));
        // priority 2: Phase 2+ set pieces (MOVE flag -> they pause melee while they run)
        this.goalSelector.addGoal(2, new SteveGoals.SummonHordeGoal(this));
        this.goalSelector.addGoal(2, new SteveGoals.ShieldParryGoal(this));
        // priority 3: Phase 3 replaces plain melee; TNT has no flags so it runs alongside movement
        this.goalSelector.addGoal(3, new SteveGoals.RushAndBarrageGoal(this));
        this.goalSelector.addGoal(3, new SteveGoals.TntSurpriseGoal(this));
        // priority 4: default PvP behaviour (Phase 1 and 2)
        this.goalSelector.addGoal(4, new SteveGoals.CriticalMeleeGoal(this));
        this.goalSelector.addGoal(6, new WaterAvoidingRandomStrollGoal(this, 1.0));
        this.goalSelector.addGoal(7, new LookAtPlayerGoal(this, Player.class, 16.0f));

        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, false));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_PHASE, 0);
        this.entityData.define(DATA_STATE, 0);
    }

    // ------------------------------------------------------------------ per-tick logic

    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        bossEvent.setProgress(getHealth() / getMaxHealth());

        updatePhase();

        // cooldown bookkeeping
        cooldowns.replaceAll((ability, ticks) -> Math.max(0, ticks - 1));
        if (meleeCooldown > 0) meleeCooldown--;
        if (lockTicks > 0) lockTicks--;
        if (shieldTicks > 0 && --shieldTicks == 0) endShield();
        if (shotReactionTicks > 0) shotReactionTicks--;
        if (stateTicks > 0 && --stateTicks == 0) entityData.set(DATA_STATE, State.NONE.ordinal());

        // "target out of melee range" timer used by the teleport trigger
        LivingEntity target = getTarget();
        if (target != null && target.isAlive() && distanceToSqr(target) > 3.5 * 3.5) {
            ticksOutOfMelee++;
        } else {
            ticksOutOfMelee = 0;
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        // Cheap client-only aura for Phase 3 (no client class needed: Level#addParticle is common code).
        if (level().isClientSide && getPhase() == Phase.THREE && random.nextInt(2) == 0) {
            level().addParticle(ParticleTypes.SOUL_FIRE_FLAME, getRandomX(0.5), getRandomY(), getRandomZ(0.5), 0, 0.02, 0);
        }
    }

    /** Client: start the boss music the moment the entity appears in the client world. */
    @Override
    public void onAddedToWorld() {
        super.onAddedToWorld();
        if (level().isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> SteveBossMusic.start(this));
        }
    }

    // ------------------------------------------------------------------ phases

    private void updatePhase() {
        float ratio = getHealth() / getMaxHealth();
        Phase wanted = ratio <= PHASE_THREE_RATIO ? Phase.THREE : ratio <= PHASE_TWO_RATIO ? Phase.TWO : Phase.ONE;
        // Phases only ever go UP. The totem heal (100 HP = exactly 20%) keeps him in Phase 3.
        if (wanted.ordinal() > getPhase().ordinal()) {
            enterPhase(wanted);
        }
    }

    private void enterPhase(Phase newPhase) {
        entityData.set(DATA_PHASE, newPhase.ordinal());
        lockTicks = 50;                      // 2.5 s roar; match your PHASE_ROAR animation length
        setAbilityState(State.PHASE_ROAR, 50);
        shieldTicks = 0;
        stopUsingItem();
        bossEvent.setColor(newPhase == Phase.TWO ? BossEvent.BossBarColor.RED : BossEvent.BossBarColor.YELLOW);

        if (level() instanceof ServerLevel sl) {
            sl.playSound(null, getX(), getY(), getZ(), SteveSounds.PHASE_ROAR.get(), SoundSource.HOSTILE, 3.0f, 0.8f);
            sl.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, getX(), getY() + 1.0, getZ(), 80, 0.6, 1.0, 0.6, 0.08);
            sl.sendParticles(ParticleTypes.FLASH, getX(), getY() + 1.0, getZ(), 1, 0, 0, 0, 0);
            shockwave(7.0, 1.4f, 0.0f);
            String title = newPhase == Phase.TWO ? "Steve calls for backup..." : "Steve is enraged!";
            for (ServerPlayer p : bossEvent.getPlayers()) {
                p.displayClientMessage(Component.literal(title), true);
            }
        }
    }

    // ------------------------------------------------------------------ damage handling

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide) return super.hurt(source, amount);
        boolean bypass = source.is(DamageTypeTags.BYPASSES_INVULNERABILITY); // /kill, void

        // Invulnerable during roar / totem animation
        if (lockTicks > 0 && !bypass) return false;

        // ---- Shield: full negate. Melee gets punished with the parry counter. ----
        if (shieldTicks > 0 && !bypass) {
            Entity direct = source.getDirectEntity();
            if (direct instanceof LivingEntity attacker && direct == source.getEntity()) {
                parryCounter(attacker);
                return false;
            }
            if (source.is(DamageTypeTags.IS_PROJECTILE)) {
                level().playSound(null, getX(), getY(), getZ(), SoundEvents.SHIELD_BLOCK, SoundSource.HOSTILE, 1.0f, 1.0f);
                return false;
            }
        }

        // ---- Projectile damage arms the teleport-behind reaction for 1 second ----
        if (source.is(DamageTypeTags.IS_PROJECTILE)) {
            shotReactionTicks = 20;
        }

        return super.hurt(source, bypass ? amount : Math.min(amount, DAMAGE_CAP));
    }

    /**
     * actuallyHurt runs AFTER armor/resistance and BEFORE LivingEntity#hurt checks isDeadOrDying(), so healing
     * here cleanly cancels the death. That is why the totem pop lives in this override.
     */
    @Override
    protected void actuallyHurt(DamageSource source, float amount) {
        super.actuallyHurt(source, amount);
        if (!level().isClientSide && !totemUsed && getHealth() <= 0.0f
                && !source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            popTotem();
        }
    }

    private void popTotem() {
        totemUsed = true;
        setHealth(TOTEM_HEAL);
        removeAllEffects();
        addEffect(new MobEffectInstance(MobEffects.GLOWING, 200, 0, false, false));
        addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 2, false, true)); // Resistance III, 10 s
        shieldTicks = 0;
        stopUsingItem();
        lockTicks = 40;
        setAbilityState(State.TOTEM, 40);
        // Vanilla totem particles + sound, free: LivingEntity#handleEntityEvent(35) runs on every tracking client.
        level().broadcastEntityEvent(this, (byte) 35);
        shockwave(12.0, 2.2f, 8.0f);
    }

    /** Sweeping counter-attack after a successful parry. */
    private void parryCounter(LivingEntity attacker) {
        shieldTicks = 0;
        stopUsingItem();
        setAbilityState(State.PARRY_STRIKE, 12);
        swing(InteractionHand.MAIN_HAND);
        if (!(level() instanceof ServerLevel sl)) return;

        sl.playSound(null, getX(), getY(), getZ(), SteveSounds.PARRY.get(), SoundSource.HOSTILE, 1.5f, 0.9f);
        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.HOSTILE, 1.5f, 0.8f);

        Vec3 look = Vec3.directionFromRotation(0, getYRot());
        for (int i = -1; i <= 1; i++) { // 3-point arc of sweep particles
            Vec3 p = position().add(look.yRot((float) Math.toRadians(i * 35)).scale(1.8));
            sl.sendParticles(ParticleTypes.SWEEP_ATTACK, p.x, getY(0.6), p.z, 1, 0, 0, 0, 0);
        }

        AABB box = getBoundingBox().inflate(3.0, 0.5, 3.0);
        for (Player p : sl.getEntitiesOfClass(Player.class, box, pl -> !pl.isSpectator())) {
            p.hurt(damageSources().mobAttack(this), 10.0f);
            p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 1));
            p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
            p.knockback(0.8, getX() - p.getX(), getZ() - p.getZ());
        }
        startCooldown(Ability.SHIELD, 160);
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        if (level() instanceof ServerLevel sl) {
            for (UUID id : minionIds) {
                Entity e = sl.getEntity(id);
                if (e != null) e.kill();
            }
            minionIds.clear();
        }
    }

    // ------------------------------------------------------------------ shared combat helpers

    /** Melee hit used by every goal. Handles cooldown, crit multiplier, knockback and feedback FX. */
    public boolean tryMeleeHit(LivingEntity target, boolean critical) {
        if (meleeCooldown > 0 || level().isClientSide) return false;
        meleeCooldown = critical ? 16 : 10;
        swing(InteractionHand.MAIN_HAND);

        float dmg = (float) getAttributeValue(Attributes.ATTACK_DAMAGE) * (critical ? CRIT_MULTIPLIER : 1.0f);
        boolean hit = target.hurt(damageSources().mobAttack(this), dmg);
        if (hit) {
            // knockback(strength, ratioX, ratioZ) pushes AWAY from the ratio vector => pass vector towards the attacker
            target.knockback(critical ? 0.9 : 0.4, getX() - target.getX(), getZ() - target.getZ());
            if (level() instanceof ServerLevel sl) {
                if (critical) {
                    sl.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY(0.5), target.getZ(), 18, 0.3, 0.3, 0.3, 0.4);
                    sl.playSound(null, target.blockPosition(), SoundEvents.PLAYER_ATTACK_CRIT, SoundSource.HOSTILE, 1.2f, 1.0f);
                } else {
                    sl.playSound(null, target.blockPosition(), SoundEvents.PLAYER_ATTACK_STRONG, SoundSource.HOSTILE, 1.0f, 1.0f);
                }
            }
        }
        return hit;
    }

    /** Jump towards the target; the goal then lands a critical on the way down. */
    public void leapAt(LivingEntity target) {
        Vec3 d = new Vec3(target.getX() - getX(), 0, target.getZ() - getZ());
        if (d.lengthSqr() < 1.0E-4) return;
        d = d.normalize();
        setDeltaMovement(d.x * 0.55, 0.62, d.z * 0.55);
        hasImpulse = true;
        setAbilityState(State.CRIT_LEAP, 18);
        playSound(SoundEvents.PLAYER_ATTACK_SWEEP, 1.0f, 1.2f);
    }

    /**
     * Radial knockback pulse used by the ground slam, phase roars and the totem pop.
     * Particles are sent with count=0 so the offset vector becomes the particle velocity (cheap expanding rings).
     */
    public void shockwave(double radius, float knockback, float damage) {
        if (!(level() instanceof ServerLevel sl)) return;
        Vec3 c = position();

        sl.playSound(null, getX(), getY(), getZ(), SoundEvents.GENERIC_EXPLODE, SoundSource.HOSTILE, 2.0f, 0.7f);
        sl.playSound(null, getX(), getY(), getZ(), SteveSounds.SLAM.get(), SoundSource.HOSTILE, 1.5f, 0.6f);

        for (int ring = 0; ring < 3; ring++) {
            for (int i = 0; i < 40; i++) {
                double a = i * (Math.PI * 2 / 40);
                sl.sendParticles(ParticleTypes.CLOUD, c.x + Math.cos(a), c.y + 0.15, c.z + Math.sin(a),
                        0, Math.cos(a), 0.02, Math.sin(a), 0.35 + ring * 0.2);
            }
        }
        var below = sl.getBlockState(blockPosition().below());
        if (!below.isAir()) {
            sl.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, below), c.x, c.y + 0.2, c.z, 60, 2.0, 0.1, 2.0, 0.2);
        }

        for (Player p : sl.getEntitiesOfClass(Player.class, getBoundingBox().inflate(radius, 3.0, radius),
                pl -> !pl.isSpectator() && pl.distanceToSqr(this) <= radius * radius)) {
            Vec3 dir = new Vec3(p.getX() - getX(), 0, p.getZ() - getZ());
            dir = dir.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : dir.normalize();
            if (damage > 0) p.hurt(damageSources().mobAttack(this), damage);
            p.setDeltaMovement(dir.x * knockback, 0.55, dir.z * knockback);
            p.hurtMarked = true; // forces a velocity packet to the client
        }
    }

    // ------------------------------------------------------------------ public API for goals

    public Phase getPhase() { return Phase.values()[Math.min(entityData.get(DATA_PHASE), Phase.values().length - 1)]; }
    public State getAbilityState() { return State.values()[Math.min(entityData.get(DATA_STATE), State.values().length - 1)]; }
    public void setAbilityState(State state, int durationTicks) {
        entityData.set(DATA_STATE, state.ordinal());
        stateTicks = durationTicks;
    }

    public boolean isLocked() { return lockTicks > 0; }
    public boolean isShielding() { return shieldTicks > 0; }
    public int getShieldTicks() { return shieldTicks; }

    public boolean isReady(Ability a) { return cooldowns.getOrDefault(a, 0) <= 0; }
    /** Phase 3 runs every ability 30% faster. */
    public void startCooldown(Ability a, int ticks) {
        cooldowns.put(a, getPhase() == Phase.THREE ? (int) (ticks * 0.7f) : ticks);
    }

    public int getTicksOutOfMelee() { return ticksOutOfMelee; }
    public void resetOutOfMelee() { ticksOutOfMelee = 0; }
    public boolean wasRecentlyShot() { return shotReactionTicks > 0; }
    public void clearShotReaction() { shotReactionTicks = 0; }
    public void resetMeleeCooldown() { meleeCooldown = 0; }

    public void beginShield() {
        shieldTicks = SHIELD_DURATION;
        setItemSlot(EquipmentSlot.OFFHAND, new ItemStack(Items.SHIELD));
        startUsingItem(InteractionHand.OFF_HAND);
        setAbilityState(State.SHIELD, SHIELD_DURATION);
        playSound(SoundEvents.SHIELD_BLOCK, 0.8f, 1.4f);
    }

    public void endShield() {
        shieldTicks = 0;
        stopUsingItem();
        setItemSlot(EquipmentSlot.OFFHAND, ItemStack.EMPTY);
    }

    public void equipSword() { setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD)); }
    public void equipBow() { setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.BOW)); }

    public void setGigaSprint(boolean on) {
        AttributeInstance speed = getAttribute(Attributes.MOVEMENT_SPEED);
        if (speed == null) return;
        speed.removeModifier(GIGA_SPRINT_UUID);
        if (on) {
            speed.addTransientModifier(new AttributeModifier(GIGA_SPRINT_UUID, "Steve giga sprint", 0.45,
                    AttributeModifier.Operation.MULTIPLY_BASE));
        }
    }

    public void registerMinion(Entity minion) { minionIds.add(minion.getUUID()); }

    public int countMinions() {
        if (level() instanceof ServerLevel sl) {
            minionIds.removeIf(id -> {
                Entity e = sl.getEntity(id);
                return e == null || !e.isAlive();
            });
        }
        return minionIds.size();
    }

    // ------------------------------------------------------------------ boss bar plumbing

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public void setCustomName(Component name) {
        super.setCustomName(name);
        bossEvent.setName(getDisplayName());
    }

    // ------------------------------------------------------------------ misc entity config

    @Override public boolean removeWhenFarAway(double distance) { return false; }
    @Override public boolean canChangeDimensions() { return false; }
    @Override protected SoundEvent getHurtSound(DamageSource src) { return SoundEvents.PLAYER_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.PLAYER_DEATH; }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putBoolean("TotemUsed", totemUsed);
        tag.putInt("Phase", getPhase().ordinal());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        totemUsed = tag.getBoolean("TotemUsed");
        entityData.set(DATA_PHASE, tag.getInt("Phase"));
        if (hasCustomName()) bossEvent.setName(getDisplayName());
    }
}
