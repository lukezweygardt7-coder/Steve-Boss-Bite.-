package com.example.steveboss;

import com.example.steveboss.entity.SteveBossEntity;

import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.level.ExplosionEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Event glue. Assumes your main mod class is `SteveBossMod` with `public static final String MODID`,
 * and that you register `ModEntities.STEVE_BOSS` (see IMPLEMENTATION_GUIDE.md section 1).
 */
public final class SteveBossEvents {

    private SteveBossEvents() {}

    /** MOD bus: attach the attribute set to the entity type. */
    @Mod.EventBusSubscriber(modid = SteveBossMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
    public static final class ModBus {
        @SubscribeEvent
        public static void onAttributes(EntityAttributeCreationEvent event) {
            event.put(ModEntities.STEVE_BOSS.get(), SteveBossEntity.createAttributes().build());
        }
    }

    /** FORGE bus: make Steve's TNT harmless to terrain, to himself, and to his own zombies. */
    @Mod.EventBusSubscriber(modid = SteveBossMod.MODID)
    public static final class ForgeBus {
        @SubscribeEvent
        public static void onDetonate(ExplosionEvent.Detonate event) {
            Entity source = event.getExplosion().getDirectSourceEntity();
            if (source == null || !source.getTags().contains(SteveBossEntity.TAG_TNT)) return;

            event.getAffectedBlocks().clear(); // arena stays intact; only players take damage
            event.getAffectedEntities().removeIf(e ->
                    e instanceof SteveBossEntity || e.getTags().contains(SteveBossEntity.TAG_MINION));
        }
    }
}
