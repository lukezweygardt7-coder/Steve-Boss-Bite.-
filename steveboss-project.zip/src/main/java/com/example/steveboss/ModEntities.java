package com.example.steveboss;

import com.example.steveboss.entity.SteveBossEntity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, SteveBossMod.MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, SteveBossMod.MODID);

    public static final RegistryObject<EntityType<SteveBossEntity>> STEVE_BOSS = ENTITIES.register("steve_boss",
            () -> EntityType.Builder.of(SteveBossEntity::new, MobCategory.MONSTER)
                    .sized(0.6f, 1.8f)          // player-sized hitbox
                    .clientTrackingRange(16)
                    .fireImmune()
                    .build("steve_boss"));

    // Blue + purple egg to match the skin
    public static final RegistryObject<Item> STEVE_SPAWN_EGG = ITEMS.register("steve_boss_spawn_egg",
            () -> new ForgeSpawnEggItem(STEVE_BOSS, 0x2FB5C9, 0x6B2FBE, new Item.Properties()));

    private ModEntities() {}
}
