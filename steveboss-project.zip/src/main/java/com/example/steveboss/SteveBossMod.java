package com.example.steveboss;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

/** Mod entry point: registers the entity, spawn egg and sounds. */
@Mod(SteveBossMod.MODID)
public class SteveBossMod {

    public static final String MODID = "steveboss";

    public SteveBossMod() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(modBus);
        ModEntities.ITEMS.register(modBus);
        SteveSounds.register(modBus);
        modBus.addListener(this::addToCreativeTabs);
    }

    /** Puts the Steve spawn egg in the vanilla "Spawn Eggs" creative tab (works on touch screens, no commands needed). */
    private void addToCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        if (event.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
            event.accept(ModEntities.STEVE_SPAWN_EGG);
        }
    }
}
